import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import altair as alt

st.markdown('Paola Plascencia Rey - A01707495')

st.title('Police Incidents Reports from 2018 to 2020 in San Francisco')
df = pd.read_csv('Police_Department_Incident_Reports__2018_to_Present.csv')

st.markdown('The data shown below belongs to incident reports in the city of San Francisco, from the year 2018 to 2020, with details from each case such as date, day of the week, police district, neighborhood in which it happened, type of incident in category and subcategory, exact location and resolution.')

mapa = pd.DataFrame()
mapa['Date'] = df['Incident Date']
mapa['Incident Time'] = df['Incident Time']
mapa['Incident Year'] = df['Incident Year']
mapa['Day'] = df['Incident Day of Week']
mapa['Police District'] = df['Police District']
mapa['Neighborhood'] = df['Analysis Neighborhood']
mapa['Incident Category'] = df['Incident Category']
mapa['Incident Subcategory'] = df['Incident Subcategory']
mapa['Resolution'] = df['Resolution']
mapa['lat'] = df['Latitude']
mapa['lon'] = df['Longitude']

mapa = mapa.dropna()

subset_data2 = mapa
police_district_input = st.sidebar.multiselect(
    'Police District',
    mapa.groupby('Police District').count().reset_index()['Police District'].tolist())

if len(police_district_input) > 0:
    subset_data2 = mapa[mapa['Police District'].isin(police_district_input)]

subset_data1 = subset_data2
neighborhood_input = st.sidebar.multiselect(
    'Neighborhood',
    subset_data2.groupby('Neighborhood').count().reset_index()['Neighborhood'].tolist())

if len(neighborhood_input) > 0:
    subset_data1 = subset_data2[subset_data2['Neighborhood'].isin(neighborhood_input)]

subset_data = subset_data1
incident_input = st.sidebar.multiselect(
    'Incident Category',
    subset_data1.groupby('Incident Category').count().reset_index()['Incident Category'].tolist())

if len(incident_input) > 0:
    subset_data = subset_data1[subset_data1['Incident Category'].isin(incident_input)]

#Se añadio un filtro por subcategoria
subset_data3 = subset_data
subincident_input = st.sidebar.multiselect(
    'Incident Subcategory',
    subset_data.groupby('Incident Subcategory').count().reset_index()['Incident Subcategory'].tolist())

if len(subincident_input) > 0:
    subset_data3 = subset_data[subset_data['Incident Subcategory'].isin(subincident_input)]


st.markdown('It is important to mention that any police district can answer to any incident, the neighborhood in which it happened is not related to the police district.')
st.markdown('Crime locations in San Francisco')
st.map(subset_data3)

st.info("Número de crímenes:")
st.success(len(subset_data3))

#grafica interactiva que muestre los crimenes por dia y el tipo
st.markdown('Crimenes por día y tipo de crimen')
click = alt.selection_multi(encodings= ['color'])
color_scale = alt.Scale(scheme='blues')
graf8=alt.Chart(subset_data3).mark_bar().encode(
    y='count()',
    x='Day',
    color= alt.condition(click,'Day', alt.value('lightgray'), scale=color_scale),
).add_selection(
    click
)
graf8_2=alt.Chart(subset_data3).mark_bar().encode(
    x='Incident Category',
    y='count()',
    color= 'Incident Category',
).transform_filter(
    click
)
graf8=graf8|graf8_2
st.altair_chart(graf8, use_container_width=True)


#crimenes ocurridos por día
st.markdown('Crimes occurred per date')
st.line_chart(subset_data3['Date'].value_counts())


#Grafica del estatus resolucion de casos 
st.markdown('Resolución de casos')
resolution_counts = subset_data3['Resolution'].value_counts().reset_index()
resolution_counts.columns = ['Resolution', 'Count']
chart = alt.Chart(resolution_counts).mark_bar().encode(
    x='Count',
    y=alt.Y('Resolution', sort='-x')
)
st.altair_chart(chart, use_container_width=True)


# grafica de los incidentes por hora del día
subset_data3['Incident Hour'] = pd.to_datetime(subset_data3['Incident Time']).dt.hour
st.markdown('Incidentes por hora del día')
hour_counts = subset_data3['Incident Hour'].value_counts().sort_index().reset_index()
hour_counts.columns = ['Hour', 'Count']
chart = alt.Chart(hour_counts).mark_bar().encode(
    x='Hour',
    y='Count'
)
st.altair_chart(chart, use_container_width=True)


#grafica del conteo de crimenes por año
year_counts = subset_data3['Incident Year'].value_counts().sort_index().reset_index()
year_counts.columns = ['Year', 'Count']
chart = alt.Chart(year_counts).mark_arc().encode(
    theta='Count:Q',
    color='Year:N',
    tooltip=['Year:N', 'Count:Q']
).properties(
    width=300,
    height=300,
    title='Distribución de incidentes por año'
)
st.altair_chart(chart, use_container_width=True)